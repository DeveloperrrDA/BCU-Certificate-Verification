<?php
/**
 * Plugin Name: Burco Central University Certificate QR Verifier
 * Description: Manage graduate records and create downloadable QR codes linking to certificate verification pages.
 * Version: 1.2.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) exit;

class SCQV_Plugin {
    const UNIVERSITY = 'Burco Central University';
    const TYPE = 'scqv_student';
    const NONCE = 'scqv_save_student';
    public static function init() {
        add_action('init', [__CLASS__, 'register']);
        add_action('template_redirect', [__CLASS__, 'serve_verification'], 0);
        add_action('add_meta_boxes', [__CLASS__, 'metabox']);
        add_action('save_post_' . self::TYPE, [__CLASS__, 'save'], 10, 2);
        add_filter('the_content', [__CLASS__, 'verification_content']);
        add_filter('manage_' . self::TYPE . '_posts_columns', [__CLASS__, 'columns']);
        add_action('manage_' . self::TYPE . '_posts_custom_column', [__CLASS__, 'column_value'], 10, 2);
        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_assets']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'public_assets']);
    }
    public static function register() {
        register_post_type(self::TYPE, [
            'labels' => ['name'=>'BCU Student Certificates','singular_name'=>'Student Certificate','add_new_item'=>'Add Student Certificate','edit_item'=>'Edit Student Certificate'],
            'public'=>false, 'show_ui'=>true, 'publicly_queryable'=>false, 'exclude_from_search'=>true,
            'show_in_rest'=>false, 'has_archive'=>false, 'rewrite'=>['slug'=>'verify-certificate'],
            'supports'=>['title'], 'menu_icon'=>'dashicons-welcome-learn-more',
            'capabilities'=>[
                'edit_post'=>'manage_options', 'read_post'=>'manage_options', 'delete_post'=>'manage_options',
                'edit_posts'=>'manage_options', 'edit_others_posts'=>'manage_options',
                'publish_posts'=>'manage_options', 'read_private_posts'=>'manage_options',
                'delete_posts'=>'manage_options', 'delete_private_posts'=>'manage_options',
                'delete_published_posts'=>'manage_options', 'delete_others_posts'=>'manage_options',
                'edit_private_posts'=>'manage_options', 'edit_published_posts'=>'manage_options',
                'create_posts'=>'manage_options',
            ], 'map_meta_cap'=>false,
        ]);
    }
    public static function fields() {
        return [
            'student_name'=>['Student full name','text'],
            'graduate_of'=>['Graduate of (Faculty / Department / Program)','text'],
            'certificate_type'=>['Certificate / Degree type','text'],
            'gpa'=>['GPA / CGPA','text'],
            'grading_scale'=>['Grading scale (e.g. 4.0)','text'],
            'graduation_date'=>['Graduation date','date'],
            'issue_date'=>['Certificate issue date','date'],
            'certificate_number'=>['Certificate serial number','text'],
            'status'=>['Verification status','select'],
            'photo_id'=>['Student photo','media'],
        ];
    }
    public static function metabox() {
        add_meta_box('scqv_details', 'Student Academic Details & QR Code', [__CLASS__, 'render_metabox'], self::TYPE, 'normal', 'high');
    }
    public static function render_metabox($post) {
        wp_nonce_field(self::NONCE, 'scqv_nonce');
        echo '<p><strong>Issuing university: '.esc_html(self::UNIVERSITY).'</strong> (fixed for all certificates).</p>';
        echo '<p>Enter details, choose a student photo, then <strong>Publish</strong> or <strong>Update</strong> to activate the verification page.</p><table class="form-table"><tbody>';
        foreach (self::fields() as $key=>$field) {
            $val = get_post_meta($post->ID, '_scqv_'.$key, true);
            echo '<tr><th><label for="scqv_'.esc_attr($key).'">'.esc_html($field[0]).'</label></th><td>';
            if ($field[1] === 'select') {
                echo '<select id="scqv_status" name="scqv_status">';
                foreach (['valid'=>'Valid','pending'=>'Pending','revoked'=>'Revoked'] as $k=>$label) echo '<option value="'.esc_attr($k).'" '.selected($val ?: 'pending',$k,false).'>'.esc_html($label).'</option>';
                echo '</select>';
            } elseif ($field[1] === 'media') {
                $img = $val ? wp_get_attachment_image((int)$val,'thumbnail',false,['style'=>'max-width:120px;height:auto']) : '';
                echo '<input type="hidden" id="scqv_photo_id" name="scqv_photo_id" value="'.esc_attr($val).'" /><div id="scqv_photo_preview">'.$img.'</div><button type="button" class="button" id="scqv_pick_photo">Choose Photo</button> <button type="button" class="button" id="scqv_remove_photo">Remove</button>';
            } else {
                echo '<input class="regular-text" type="'.esc_attr($field[1]).'" id="scqv_'.esc_attr($key).'" name="scqv_'.esc_attr($key).'" value="'.esc_attr($val).'" />';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table>';
        if ($post->post_status === 'publish' && get_post_meta($post->ID, '_scqv_token', true)) {
            $url = self::verification_url($post->ID);
            echo '<hr><h3>Certificate QR Code</h3><p>Verification link: <a target="_blank" rel="noopener noreferrer" href="'.esc_url($url).'">'.esc_html($url).'</a></p><div class="scqv-qr" data-qr-url="'.esc_attr($url).'"></div><p><button type="button" class="button button-primary scqv-download">Download QR PNG</button></p>';
        } else echo '<p><em>Publish the certificate to generate its QR code.</em></p>';
    }
    public static function save($id, $post) {
        if (!isset($_POST['scqv_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['scqv_nonce'])), self::NONCE)) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($id) || !current_user_can('manage_options')) return;
        update_post_meta($id, '_scqv_institution', self::UNIVERSITY);
        if (!get_post_meta($id, '_scqv_token', true)) update_post_meta($id, '_scqv_token', bin2hex(random_bytes(20)));
        foreach (self::fields() as $key=>$field) {
            $input = 'scqv_'.$key;
            if (!isset($_POST[$input]) || is_array($_POST[$input])) continue;
            $raw = wp_unslash($_POST[$input]);
            if ($key === 'photo_id') {
                $val = absint($raw);
                if ($val && !wp_attachment_is_image($val)) $val = 0;
            } elseif ($key === 'status') $val = in_array($raw,['valid','pending','revoked'],true) ? $raw : 'pending';
            elseif ($field[1] === 'date') $val = preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw) ? $raw : '';
            else $val = sanitize_text_field($raw);
            update_post_meta($id, '_scqv_'.$key, $val);
        }
        $name = get_post_meta($id,'_scqv_student_name',true);
        if ($name && $post->post_title !== $name) {
            remove_action('save_post_'.self::TYPE,[__CLASS__,'save'],10);
            wp_update_post(['ID'=>$id,'post_title'=>$name]);
            add_action('save_post_'.self::TYPE,[__CLASS__,'save'],10,2);
        }
    }

    public static function verification_url($id) {
        $token = get_post_meta($id, '_scqv_token', true);
        return $token ? add_query_arg('bcu_verify', $token, home_url('/')) : '';
    }
    public static function serve_verification() {
        if (!isset($_GET['bcu_verify'])) return;
        $token = sanitize_text_field(wp_unslash($_GET['bcu_verify']));
        if (!preg_match('/^[a-f0-9]{40}$/', $token)) { self::verification_error(); return; }
        $records = get_posts(['post_type'=>self::TYPE,'post_status'=>'publish','meta_key'=>'_scqv_token','meta_value'=>$token,'posts_per_page'=>1,'no_found_rows'=>true]);
        if (!$records) { self::verification_error(); return; }
        $id = $records[0]->ID;
        $status = get_post_meta($id, '_scqv_status', true) ?: 'pending';
        nocache_headers(); header('X-Robots-Tag: noindex, nofollow', true);
        status_header(200);
        $photo_id = absint(get_post_meta($id,'_scqv_photo_id',true));
        $fields = self::fields();
        $labels = ['valid'=>'VALID','pending'=>'PENDING','revoked'=>'REVOKED'];
        $html = '<div class="bcu-panel"><div class="bcu-header"><div class="bcu-mark">BCU</div><div><h1>Burco Central University</h1><p>Official Certificate Verification</p></div></div>';
        $html .= '<div class="bcu-status bcu-'.esc_attr($status).'">'.esc_html($labels[$status] ?? 'PENDING').'</div>';
        if ($status === 'valid') {
            if ($photo_id) $html .= '<div class="bcu-photo">'.wp_get_attachment_image($photo_id, 'medium', false, ['alt'=>'Student photograph']).'</div>';
            $html .= '<dl><dt>University</dt><dd>Burco Central University</dd>';
            foreach ($fields as $key=>$field) {
                if (in_array($key,['status','photo_id'],true)) continue;
                $value = get_post_meta($id,'_scqv_'.$key,true);
                if ($value !== '') $html .= '<dt>'.esc_html($field[0]).'</dt><dd>'.esc_html($value).'</dd>';
            }
            $html .= '</dl>';
        } else {
            $html .= '<p class="bcu-message">This certificate is not currently verified as valid. Contact the university registrar for confirmation.</p>';
        }
        $html .= '<footer>Verify any discrepancies directly with Burco Central University.</footer></div>';
        self::page($html);
    }
    private static function verification_error() {
        nocache_headers(); header('X-Robots-Tag: noindex, nofollow', true); status_header(404);
        self::page('<div class="bcu-panel"><div class="bcu-header"><div class="bcu-mark">BCU</div><div><h1>Burco Central University</h1><p>Certificate Verification</p></div></div><div class="bcu-status bcu-revoked">RECORD NOT FOUND</div><p class="bcu-message">No published certificate matches this verification code.</p></div>');
    }
    private static function page($body) {
        header('Content-Type: text/html; charset='.get_bloginfo('charset'));
        echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>BCU Certificate Verification</title><style>body{margin:0;background:#edf3f9;font:16px/1.5 system-ui,Arial,sans-serif;color:#1b3148;padding:35px 15px}.bcu-panel{background:white;max-width:720px;margin:auto;border-radius:15px;overflow:hidden;box-shadow:0 8px 30px #18345219}.bcu-header{background:#123a65;color:white;display:flex;align-items:center;gap:16px;padding:26px}.bcu-mark{background:white;color:#123a65;font-weight:800;border-radius:10px;padding:16px}.bcu-header h1{font-size:22px;margin:0}.bcu-header p{margin:4px 0 0}.bcu-status{text-align:center;margin:25px auto 12px;width:max-content;padding:9px 25px;border-radius:99px;font-weight:700;background:#d9f6e5;color:#12603a}.bcu-pending{background:#fff0c7;color:#765000}.bcu-revoked{background:#ffe0e0;color:#a11c1c}.bcu-photo{text-align:center;margin:22px}.bcu-photo img{width:145px;height:175px;object-fit:cover;border-radius:8px}dl{display:grid;grid-template-columns:42% 58%;margin:20px 28px}dt,dd{padding:12px 8px;border-bottom:1px solid #e5edf4;margin:0;overflow-wrap:anywhere}dt{color:#60748a}dd{font-weight:600}footer{padding:22px;text-align:center;background:#f5f8fc;font-size:13px;color:#52677a}.bcu-message{padding:20px 30px;text-align:center}@media(max-width:480px){dl{grid-template-columns:1fr}dt{border:0;padding-bottom:0}dd{padding-top:0}.bcu-header h1{font-size:17px}}</style></head><body>'.$body.'</body></html>';
        exit;
    }

    public static function verification_content($content) {
        if (!is_singular(self::TYPE) || !in_the_loop() || !is_main_query()) return $content;
        $id = get_the_ID();
        $status = get_post_meta($id,'_scqv_status',true) ?: 'pending';
        $labels = ['valid'=>'VALID','pending'=>'PENDING VERIFICATION','revoked'=>'REVOKED'];
        $photo_id = absint(get_post_meta($id,'_scqv_photo_id',true));
        $html = '<section class="scqv-verification"><h2>'.esc_html(self::UNIVERSITY).'</h2><h3>Official Certificate Verification</h3><p class="scqv-status scqv-'.esc_attr($status).'">'.esc_html($labels[$status] ?? 'PENDING').'</p>';
        if ($status !== 'valid') {
            $html .= '<p>This certificate is not currently verified as valid. Contact Burco Central University for assistance.</p></section>';
            return $html;
        }
        if ($photo_id) $html .= '<div class="scqv-photo">'.wp_get_attachment_image($photo_id,'medium',false,['alt'=>'Student photograph']).'</div>';
        $html .= '<dl><dt>University / Institution</dt><dd>'.esc_html(self::UNIVERSITY).'</dd>';
        foreach (self::fields() as $key=>$field) {
            if (in_array($key,['status','photo_id'],true)) continue;
            $val = get_post_meta($id,'_scqv_'.$key,true);
            if ($val !== '') $html .= '<dt>'.esc_html($field[0]).'</dt><dd>'.esc_html($val).'</dd>';
        }
        $html .= '</dl><p class="scqv-note">Issued by Burco Central University. Confirm any discrepancies with the university registrar.</p></section>';
        return $html;
    }
    public static function columns($cols) {
        $cols['scqv_number']='Certificate Number'; $cols['scqv_status']='Status'; return $cols;
    }
    public static function column_value($col,$id) {
        if ($col === 'scqv_number') echo esc_html(get_post_meta($id,'_scqv_certificate_number',true));
        if ($col === 'scqv_status') echo esc_html(ucfirst(get_post_meta($id,'_scqv_status',true) ?: 'pending'));
    }
    public static function admin_assets($hook) {
        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== self::TYPE || !in_array($hook,['post.php','post-new.php'],true)) return;
        wp_enqueue_media();
        wp_enqueue_script('scqv-qrcode',plugins_url('assets/qrcode.min.js',__FILE__),[], '1.0.0',true);
        wp_enqueue_script('scqv-admin',plugins_url('assets/admin.js',__FILE__),['jquery','scqv-qrcode'],'1.0.0',true);
    }
    public static function public_assets() {
        if (!is_singular(self::TYPE)) return;
        wp_enqueue_style('scqv-public',plugins_url('assets/public.css',__FILE__),[], '1.0.0');
    }
    public static function activate() { self::register(); flush_rewrite_rules(); }
    public static function deactivate() { flush_rewrite_rules(); }
}
SCQV_Plugin::init();
register_activation_hook(__FILE__,['SCQV_Plugin','activate']);
register_deactivation_hook(__FILE__,['SCQV_Plugin','deactivate']);
