BCU Certificate QR Verifier 1.2.0

Install via Plugins > Add New > Upload Plugin. Activate.
Add Student Certificate, complete details and photograph, set Valid, Publish.
Reload editor to see QR code and Download QR PNG.
QR codes link to https://YOUR-SITE/?bcu_verify=<random token>.
Scanning opens a standalone responsive verification page; no permalink setup needed.
Use HTTPS. Disable page caching for requests with bcu_verify query parameter.
Records are public to anyone with a valid QR URL; obtain student consent and confirm privacy policy.
Only admins can create/edit records. Revoked/pending records do not show student details.
Test on staging with smartphone camera before issuing certificates.
