(function($){
'use strict';
$(function(){
  $('#scqv_pick_photo').on('click',function(e){
    e.preventDefault();
    const frame=wp.media({title:'Choose Student Photo',button:{text:'Use this photo'},library:{type:'image'},multiple:false});
    frame.on('select',function(){
      const item=frame.state().get('selection').first().toJSON();
      $('#scqv_photo_id').val(item.id);
      $('#scqv_photo_preview').empty().append($('<img>',{src:item.sizes?.thumbnail?.url || item.url,alt:'Student photograph',css:{maxWidth:'120px',height:'auto'}}));
    });
    frame.open();
  });
  $('#scqv_remove_photo').on('click',function(e){e.preventDefault();$('#scqv_photo_id').val('');$('#scqv_photo_preview').empty();});
  $('.scqv-qr').each(function(){
    const el=this, url=el.getAttribute('data-qr-url');
    if(typeof QRCode==='undefined') {el.textContent='QR library unavailable';return;}
    new QRCode(el,{text:url,width:320,height:320,colorDark:'#000000',colorLight:'#ffffff',correctLevel:QRCode.CorrectLevel.M});
  });
  $('.scqv-download').on('click',function(e){
    e.preventDefault();
    const qr=$(this).closest('p').prev('.scqv-qr')[0];
    if(!qr) return;
    const canvas=qr.querySelector('canvas'),img=qr.querySelector('img');
    const a=document.createElement('a');a.download='certificate-qr.png';
    a.href=canvas ? canvas.toDataURL('image/png') : (img ? img.src : '');
    if(a.href) a.click();
  });
});
})(jQuery);
